package com.hfad.tourclick

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.hfad.tourclick.databinding.FragmentTourDetailsBinding
import com.google.android.material.button.MaterialButton

class TourDetailsFragment : Fragment() {

    private var _binding: FragmentTourDetailsBinding? = null
    private val binding get() = _binding!!
    private var selectedTime: String = "09:00"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTourDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnTime9.textSize = 14f
        binding.btnTime12.textSize = 14f
        binding.btnTime15.textSize = 14f

        setupTimeButtons()
    }

    private fun setupTimeButtons() {
        val timeButtons = listOf(
            binding.btnTime9 to "09:00",
            binding.btnTime12 to "12:00",
            binding.btnTime15 to "15:00"
        )

        timeButtons.forEach { (button, time) ->
            button.setOnClickListener {
                selectTime(button, time, timeButtons)
            }
        }

        // Set initial selection
        selectTime(binding.btnTime9, "09:00", timeButtons)
    }

    private fun selectTime(selectedButton: MaterialButton, time: String, allButtons: List<Pair<MaterialButton, String>>) {
        selectedTime = time

        allButtons.forEach { (button, buttonTime) ->
            if (buttonTime == time) {
                // Зеленая кнопка для выбранного времени
                button.setBackgroundColor(requireContext().getColor(R.color.green_primary))
                button.setTextColor(requireContext().getColor(android.R.color.white))
            } else {
                // Прозрачная кнопка для невыбранного времени
                button.setBackgroundColor(requireContext().getColor(android.R.color.transparent))
                button.setTextColor(requireContext().getColor(R.color.green_primary))
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}