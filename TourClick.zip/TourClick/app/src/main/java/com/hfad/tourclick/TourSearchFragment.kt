package com.hfad.tourclick

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hfad.tourclick.databinding.FragmentTourSearchBinding
import com.hfad.tourclick.databinding.TourItemBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class TourSearchFragment : Fragment() {

    private var _binding: FragmentTourSearchBinding? = null
    private val binding get() = _binding!!
    private val calendar = Calendar.getInstance()
    private var selectedDate: String = "Select date"
    private var selectedPeople: Int = 2

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTourSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
        setupToursRecyclerView()

        // Увеличиваем размер текста на кнопках
        binding.findButton.textSize = 16f
        binding.seeAllButton.textSize = 14f
    }

    private fun setupClickListeners() {
        // Обработчик для выбора даты
        binding.dateSelection.setOnClickListener {
            showDatePicker()
        }

        // Обработчик для выбора количества людей
        binding.peopleSelection.setOnClickListener {
            showPeoplePicker()
        }

        // Обработчик для кнопки поиска
        binding.findButton.setOnClickListener {
            performSearch()
        }

        // Обработчик для уведомлений
        binding.notificationIcon.setOnClickListener {
            // TODO: Переход к экрану уведомлений
        }
    }

    private fun showDatePicker() {
        val datePicker = DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                calendar.set(year, month, dayOfMonth)
                val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                selectedDate = dateFormat.format(calendar.time)
                binding.selectedDateText.text = selectedDate
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.show()
    }

    private fun showPeoplePicker() {
        // Простой выбор количества людей (можно заменить на диалог)
        selectedPeople = if (selectedPeople >= 10) 1 else selectedPeople + 1
        binding.peopleCountText.text = selectedPeople.toString()
    }

    private fun performSearch() {
        // TODO: Реализовать логику поиска туров
        // Пока просто переходим к деталям тура
        findNavController().navigate(R.id.action_tourSearchFragment_to_tourDetailsFragment)
    }

    private fun setupToursRecyclerView() {
        val tours = listOf(
            Tour("Eco City Highlights", "Discover the city's must-see eco landmarks", 35, R.drawable.tour_eco_city),
            Tour("Mountain Adventure", "Explore breathtaking mountain landscapes", 45, R.drawable.tour_mountain),
            Tour("Historic Downtown", "Journey through historic city center", 30, R.drawable.tour_historic),
            Tour("River Cruise", "Relaxing cruise along the scenic river", 55, R.drawable.tour_river),
            Tour("Forest Trek", "Guided tour through ancient forests", 40, R.drawable.tour_placeholder),
            Tour("Coastal Tour", "Stunning views along the coastline", 50, R.drawable.tour_placeholder)
        )

        val adapter = ToursAdapter(tours) { tour ->
            findNavController().navigate(R.id.action_tourSearchFragment_to_tourDetailsFragment)
        }

        binding.toursRecyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.toursRecyclerView.adapter = adapter
    }
}

class ToursAdapter(
    private val tours: List<Tour>,
    private val onTourClick: (Tour) -> Unit
) : RecyclerView.Adapter<ToursAdapter.TourViewHolder>() {

    inner class TourViewHolder(private val binding: TourItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(tour: Tour) {
            binding.tourTitle.text = tour.title
            binding.tourDescription.text = tour.description
            binding.tourPrice.text = "From $${tour.price} • Free cancellation"

            // Устанавливаем изображение (замените на ваши реальные изображения)
            binding.tourImage.setImageResource(tour.imageRes)

            binding.root.setOnClickListener {
                onTourClick(tour)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TourViewHolder {
        val binding = TourItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TourViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TourViewHolder, position: Int) {
        holder.bind(tours[position])
    }

    override fun getItemCount(): Int = tours.size
}

data class Tour(
    val title: String,
    val description: String,
    val price: Int,
    val imageRes: Int
)